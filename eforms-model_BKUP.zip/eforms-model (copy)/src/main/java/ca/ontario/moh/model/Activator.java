package ca.ontario.moh.model;

// import org.kie.api.project.KieActivator;

// @KieActivator
public class Activator {
    
}
