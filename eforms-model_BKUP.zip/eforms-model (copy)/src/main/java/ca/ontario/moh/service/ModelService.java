package ca.ontario.moh.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.ontario.dao.model.ModelRepository;
import ca.ontario.moh.model.Model;

@Service
public class ModelService {

    @Autowired
    private ModelRepository modelRepository;

    public List<Model> list() {
        return modelRepository.findAll();
    }
}